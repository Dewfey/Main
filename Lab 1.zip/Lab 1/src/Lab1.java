public class Lab1 {

    public static void main(String[] args) {




    }
}

