public class
Main
{
    public static void
    main
            (
                    String
                            []
                            args
            )
    {
// Displays the header for this program
        //displayProgramHeader
                System.out.println("Program:     Lab 1: Strings and Methods");
        System.out.println("Date:      25th, September 2022");  System.out.println("Purpose:     A simple Java application that will be used to display an information on the console."); System.out.println("Author:     Thomas Dewey Schoenfelder, University of Bridgeport");  System.out.println("References:     In class notes");  System.out.println("Course:     Introduction to Computing 1 with Java");  System.out.println("************************************************************");
        System.out.println("First Name: Thomas");  System.out.println("Last Name: Schoenfeler");  System.out.println("Full Name: Thomas Dewey Schoenfelder");  System.out.println("Natoinality: German, Italian, and Irish");  System.out.println("--------------------------------------------------");
        System.out.println("Song Title: Country Girl");
        System.out.println("Artist: Luke Bryan");
        System.out.println("Lyrics: Hey girl, go on now!\n" +
                "You know you've got everybody lookin'\n" +
                "Got a little boom in my big truck\n" +
                "Gonna open up the doors and turn it up\n" +
                "Gonna stomp my boots in the Georgia mud\n" +
                "Gonna watch you make me fall in love\n" +
                "Get up on the hood of my daddy's tractor\n" +
                "Up on the tool box, it don't matter\n" +
                "Down on the tailgate\n" +
                "Girl I can't wait\n" +
                "To watch you do your thing\n" +
                "Shake it for the young bucks sittin' in the honky-tonks\n" +
                "For the rednecks rockin' 'til the break of dawn\n" +
                "The DJ spinnin' that country song\n" +
                "C'mon, c'mon, c'mon\n" +
                "Shake it for the birds, shake it for the bees\n" +
                "Shake it for the catfish swimmin' down deep in the creek\n" +
                "For the crickets and the critters and the squirrels\n" +
                "Shake it to the moon, shake it for me girl\n" +
                "Aw, country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Somebody's sweet little farmer's child\n" +
                "With a gattle in her Bud to get a little wild\n" +
                "Pony-tail and a pretty smile\n" +
                "Rope me in from a country mile\n" +
                "So come on over here and get in my arms\n" +
                "Spin me around this big ole barn\n" +
                "Tangle me up like grandma's yarn\n" +
                "Yeah, yeah, yeah\n" +
                "Shake it for the young bucks sittin' in the honky-tonks\n" +
                "For the rednecks rockin' 'til the break of dawn\n" +
                "For the DJ spinnin' that country song\n" +
                "C'mon, c'mon, c'mon\n" +
                "Shake it for the birds, shake it for the bees\n" +
                "Shake it for the catfish swimmin' down deep in the creek\n" +
                "For the crickets and the critters and the squirrels\n" +
                "Shake it to the moon, shake it for me girl\n" +
                "Country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Guitar\n" +
                "Now dance, like a dandelion\n" +
                "In the wind on the hill underneath the pines\n" +
                "Yeah, move like the river flows\n" +
                "Feel the kick drum down deep in your toes\n" +
                "All I wanna do is get to holdin' you\n" +
                "And get to knowin' you\n" +
                "And get to showin' you\n" +
                "And get to lovin' you\n" +
                "'Fore the night is through\n" +
                "Baby, you know what to do\n" +
                "Shake it for the young bucks sittin' in the honky-tonks\n" +
                "For the rednecks rockin' 'til the break of dawn\n" +
                "For the DJ spinnin' that country song\n" +
                "C'mon, c'mon, c'mon\n" +
                "Shake it for the birds, shake it for the bees\n" +
                "Shake it for the catfish swimmin' down deep in the creek\n" +
                "For the crickets and the critters and the squirrels\n" +
                "Shake it to the moon, shake it for me girl\n" +
                "Aw, country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me, ah country girl\n" +
                "Country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Country girl, shake it for me\n" +
                "Girl, shake it for me\n" +
                "Girl, shake it for me");
        System.out.println("----------------------------------------------------------");

        System.out.println("Song Title: 4 da Gang");
        System.out.println("Artist: 42 Dugg and Roddy Rich");
        System.out.println("Lyrics: You\n" +
                "I can't wait for the nights with you\n" +
                "I imagine the things we'll do\n" +
                "Ain't nothin' plain on me, nigga, four chains on me\n" +
                "I ain't trippin' 'bout that ho, nigga, she came on me\n" +
                "I got a bitch from the West, she'll suck a nigga soul\n" +
                "Bitch from the East, she'll fuck a nigga dawgs\n" +
                "Still playin' with that raw even though I got a deal\n" +
                "Had to get up out the city, I just got a nigga killed\n" +
                "Pause, I'm lyin', kinda, still sippin' out the Fanta\n" +
                "OxyContin and Opanas, I want four-two for each\n" +
                "Niggas upped Lou for free, that's my nigga, come and kick it\n" +
                "Mister still'll serve the city, I'm the reason it's some chicken\n" +
                "Why the fuck you in the kitchen tryna turn one?\n" +
                "Daire quit pullin' on the blender 'fore you burn somе\n" +
                "Baby say she want a real nigga, but she don't gеt it\n" +
                "Why you ain't never up at night? I told you I been sippin' Turntest in the city, white lows, blue flags Know I keep two flags on bang I just dropped a Urus for the gang Catch me in the city, young nigga, four chains Signed to CMG, still in the dope game I don't swipe propane, really got it out the mud Big 4 Gang, catch me ridin' with the thugs And I got it on my own, ain't nobody helped me Remain humble, sell crack to dope fiends You can't Lil' bro me, bitch, I really got a check 42 in this shit, I be really on that Put the city on my back, still remember hard times 2018 was the year my dawg died Pull up in frog eyes, yeah nigga, we winning Amiris on low, if not wheat Timbs Me and 42 pullin' up, twin Bentleys Peanut butter seats, all my windows tinted Know I keep two flags on bang I just dropped a Urus for the gang Tied from the D to LA, always keep it a hunnid K Number one nigga, but they're never gon' admit it I was doin' two-hundred in the 'Rari and got a ticket Every time they see me, they say they ain't seen me in a minute Probably fuckin' on your bitches, probably runnin' up the digits Forgiato wheels, both lanes Floor mats say a nigga name Interrogation, feds tried to put us on the board, never identified All my niggas always gettin' dough, it's always chicken time I got niggas in the box, gon' call me collect I got model bitches that be tryna call me for sex And you know what they say, If it ain't directed, then don't respect it You see 'em out in public, they gon' act like they never said it I see by the C-side, I throw it up two times And your nigga got a gangster card, he bought it off Groupon One of the young niggas that be gettin' love in the city From the hub to the dub in the tub, fuck with me Pull up in frog eyes, yeah nigga, we winning Amiris on low, if not wheat Timbs Me and 42 pullin' up, twin Bentleys Peanut butter seats, all my windows tinted Know I keep two flags on bang I just dropped a Urus for the gang Tied from the D to LA, always keep it a hunnid K")
;
        System.out.println("----------------------------------------------------------");
        System.out.println("Song Title: The one that got away");
        System.out.println("Artist: Katy Perry");
        System.out.println("Lyrics: You know it's crazy, 'cause nights like this\n" +
               "Would start out with a little private party\n" +
       "You sneak me in your mom's house\n" +
       "I know I mighta spilled my drink, but\n" +
       "Really wasn't tryin' to spill my heart out\n" +
       "I mean it started as a conversation\n" +
       "I was really tryin' to get my thoughts out\n" +
       "But then we make moves and we make plans\n" +
       "Had the whole thing mapped out\n" +
       "See, you were gonna go to college\n" +
       "And to pay for bills I'd figure the job out\n" +
       "And you knew I had to say it, but them day's gone\n" +
       "Now I moved on and you switched phones\n" +
       "Hopefully reincarnation will bring us back to the place we belong\n" +
       "                Summer after high school when we first met\n" +
       "        We make out in your Mustang to Radiohead\n" +
       "        And on my 18th birthday we got matching tattoos\n" +
       "        Used to steal your parents' liquor and climb to the roof\n" +
       "Talk about our future like we had a clue\n" +
       "Never planned that one day, I'd be losing you\n" +
       "In another life\n" +
       "I would be your girl\n" +
       "We keep all our promises\n" +
       "Be us against the world\n" +
       "In another life\n" +
       "I would make you stay\n" +
       "So I don't have to say\n" +
       "You were the one that got away\n" +
       "The one that got away\n" +
       "I was June and you were my Johnny Cash\n" +
       "Never one without the other we made a pact\n" +
       "Sometimes when I miss you\n" +
       "I put those records on\n" +
       "Someone said you had your tattoo removed\n" +
       "Saw you downtown singing the blues\n" +
       "Its time to face the music\n" +
       "I'm no longer your muse\n" +
       "In another life\n" +
       "I would be your girl\n" +
       "We keep all our promises\n" +
       "Be us against the world\n" +
       "In another life\n" +
       "I would make you stay\n" +
       "So I don't have to say\n" +
       "You were the one that got away\n" +
       "The one that got away\n" +
       "The o-o-o-o-o-one\n" +
       "The o-o-o-o-o-one\n" +
       "The o-o-o-o-o-one\n" +
       "The one that got away\n" +
       "I'm falling for you like dominoes\n" +
       "From the top of the hundredth floor\n" +
       "Look out below Geronimo\n" +
       "Tryin' to get behind the closed doors to your soul\n" +
       "Why'd you have to end the show\n" +
       "We had such a beautiful plot\n" +
       "There was still more story to go\n" +
       "Now look, I'm not insinuating that\n" +
       "You're some type of fair weather player\n" +
       "But even if the whole world falls over\n" +
       "I wouldn't be aware of a glacier\n" +
       "I just wanna see you wake up\n" +
       "Doing your hair in the mirror with your makeup\n" +
       "Then, maybe in the next lifetime we could make up\n" +
       "In another life\n" +
       "I would be your girl\n" +
       "We keep all our promises\n" +
       "Be us against the world\n" +
       "In another life\n" +
       "I would make you stay\n" +
       "So I don't have to say\n" +
       "You were the one that got away\n" +
       "The one that got away\n" +
       "The o-o-o-o-o-one\n" +
       "The o-o-o-o-o-one\n" +
       "The o-o-o-o-o-one\n" +
       "In another life\n" +
       "I would make you stay\n" +
       "So I don't have to say\n" +
       "You were the one that got away\n" +
       "The one that got away");


        System.out.println("======================================================================");
        System.out.println("####################### END OF PROGRAM ############################");


}
    }